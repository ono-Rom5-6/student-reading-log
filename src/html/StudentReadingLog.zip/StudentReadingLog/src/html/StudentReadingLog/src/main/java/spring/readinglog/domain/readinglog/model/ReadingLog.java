package spring.readinglog.domain.readinglog.model;

public class ReadingLog {

}
